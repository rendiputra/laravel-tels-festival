@extends('layouts.user')
@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col col-md-8 col-sm-10 col-12">
                
            </div>
        </div>
    </div>
@endsection